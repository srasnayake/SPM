require('abc');
require('xyz');
require('./bar');
