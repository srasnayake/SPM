console.log(FFF * GGG);
