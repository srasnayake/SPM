console.log(WWW.toUpperCase());
