console.log(AAA + BBB + CCC + DDD + EEE + FFF);
