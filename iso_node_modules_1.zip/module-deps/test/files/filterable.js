
module.exports = {
  events: require('events'),
  fs    : require('fs'),
  net   : require('net'),
  http  : require('http'),
  https : require('https'),
  dgram : require('dgram'),
  dns   : require('dns')
}
