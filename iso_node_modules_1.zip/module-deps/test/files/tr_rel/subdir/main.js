console.log(XXX * 3)
