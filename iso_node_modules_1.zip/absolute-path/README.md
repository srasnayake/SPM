node-absolute-path
==================

Node.js 0.11.x path.isAbsolute as an installable module
